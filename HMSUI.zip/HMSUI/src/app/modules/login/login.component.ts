import { Component, OnInit } from '@angular/core';
import { FormControl, FormGroup } from '@angular/forms';

@Component({
  selector: 'app-login',
  templateUrl: './login.component.html',
  styleUrls: ['./login.component.scss']
})
export class LoginComponent implements OnInit {

  public loginForm: FormGroup = new FormGroup({
    userName: new FormControl(''),
    password: new FormControl('')
  })
  constructor()
   {
    document.body.classList.add('bg-img');
    }

  ngOnInit() {
    
  }

  doLogIn(){
    if(this.loginForm.controls['userName'].value===this.loginForm.controls['password'].value){
      localStorage.setItem('login','true');
      // if(this.loginService.isLoggedIn()){
      //   this.router.navigateByUrl('');
      // }
      
    }
    else{
      localStorage.clear();
    }
      
    
  }

  signUp(){

  }

}
